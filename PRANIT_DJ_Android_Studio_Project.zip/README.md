# PRANIT DJ — Android Studio project

A first working native Android DJ-mixer starter with:
- Two independent audio decks (A and B)
- Load audio from the phone using Android's file picker
- Play / pause for each deck
- Per-deck channel level
- Crossfader between the two decks
- Bass / Mid / Treble controls using Android's audio Equalizer effect when supported
- Dark, Pioneer-inspired mixer styling (inspired by the general layout, not using Pioneer branding)

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`PRANIT_DJ_Android_Studio`) in Android Studio.
3. Let Gradle sync. If prompted, install Android SDK Platform 35 and a compatible Android Gradle plugin.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).
6. Transfer the APK to your Android phone and install it. Only install APKs you built or trust.

## Notes
- This environment cannot compile/sign an Android APK because Android SDK/Gradle build tools are not installed here. The project source is provided so it can be built in Android Studio.
- Audio-effect support depends on the phone's Android audio implementation. Some devices may ignore or limit EQ effects.
- This is version 1.0: a functional starter mixer, not a replacement for a hardware DJ controller. Advanced beat sync, waveform analysis, cue points, looping, and latency tuning are future upgrades.
