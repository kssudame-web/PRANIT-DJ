package com.pranit.dj;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.media.MediaPlayer;
import android.media.audiofx.Equalizer;
import android.media.audiofx.BassBoost;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.io.IOException;

public class MainActivity extends Activity {
    private Deck left, right;
    private SeekBar crossfader;
    private TextView status;
    private int pickerDeck = 0;
    private final int cyan = Color.rgb(0, 217, 255);
    private final int bg = Color.rgb(8, 11, 18);

    class Deck {
        MediaPlayer player;
        Equalizer eq;
        BassBoost bass;
        String title = "No track loaded";
        TextView track, time;
        SeekBar volume, seek, low, mid, high;
        Button play;
        int index;
        Deck(int i) { index = i; }
        void load(Uri uri) {
            release();
            player = new MediaPlayer();
            try {
                player.setDataSource(MainActivity.this, uri);
                player.setOnPreparedListener(mp -> {
                    mp.start();
                    play.setText("❚❚ PAUSE");
                    seek.setMax(Math.max(1, mp.getDuration()));
                    title = "Track " + (index + 1) + " • " + uri.getLastPathSegment();
                    track.setText(title);
                    status.setText("Deck " + (index + 1) + " ready");
                    try {
                        eq = new Equalizer(0, mp.getAudioSessionId());
                        eq.setEnabled(true);
                        bass = new BassBoost(0, mp.getAudioSessionId());
                        bass.setEnabled(true);
                        applyEq();
                    } catch (Exception ignored) {}
                    updateVolumes();
                });
                player.setOnCompletionListener(mp -> play.setText("▶ PLAY"));
                player.prepareAsync();
                track.setText("Loading track...");
                status.setText("Loading Deck " + (index + 1) + "...");
            } catch (IOException e) {
                track.setText("Could not open this audio file");
                release();
            }
        }
        void applyEq() {
            if (eq == null) return;
            try {
                short bands = eq.getNumberOfBands();
                for (short b = 0; b < bands; b++) {
                    int hz = eq.getCenterFreq(b) / 1000;
                    int value = hz < 250 ? low.getProgress() - 50 :
                                hz < 2500 ? mid.getProgress() - 50 :
                                high.getProgress() - 50;
                    short range = eq.getBandLevelRange()[1];
                    short level = (short)(value * range / 100);
                    eq.setBandLevel(b, level);
                }
                if (bass != null) bass.setStrength((short)(low.getProgress() * 10));
            } catch (Exception ignored) {}
        }
        void release() {
            try { if (eq != null) eq.release(); } catch(Exception ignored) {}
            try { if (bass != null) bass.release(); } catch(Exception ignored) {}
            eq = null; bass = null;
            if (player != null) {
                try { player.stop(); } catch(Exception ignored) {}
                player.release(); player = null;
            }
        }
        void toggle() {
            if (player == null) { status.setText("Load a song first"); return; }
            if (player.isPlaying()) { player.pause(); play.setText("▶ PLAY"); }
            else { player.start(); play.setText("❚❚ PAUSE"); }
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
        left = new Deck(0); right = new Deck(1);
        buildDeck(left, findViewById(101));
        buildDeck(right, findViewById(102));
        updateVolumes();
    }

    private GradientDrawable rounded(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(22);
        d.setStroke(2, stroke); return d;
    }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); t.setGravity(Gravity.CENTER);
        return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackground(rounded(Color.rgb(25,34,48), cyan));
        return b;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(12, 10, 12, 10); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private SeekBar slider(int max, int progress) {
        SeekBar s = new SeekBar(this); s.setMax(max); s.setProgress(progress);
        s.setProgressTintList(android.content.res.ColorStateList.valueOf(cyan));
        s.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        return s;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = column(); root.setBackgroundColor(bg);
        scroll.addView(root);
        TextView title = label("PRANIT  DJ", 30, cyan);
        title.setTypeface(null, Typeface.BOLD); root.addView(title);
        TextView sub = label("DUAL DECK • LIVE MIXER", 11, Color.LTGRAY);
        root.addView(sub);
        status = label("LOAD TRACKS TO START MIXING", 12, Color.rgb(255,190,70));
        root.addView(status);
        LinearLayout decks = row();
        LinearLayout a = column(); a.setBackground(rounded(Color.rgb(16,23,34), cyan)); a.setId(101);
        LinearLayout b = column(); b.setBackground(rounded(Color.rgb(16,23,34), cyan)); b.setId(102);
        decks.addView(a, new LinearLayout.LayoutParams(0, -2, 1));
        decks.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(decks);
        TextView mixTitle = label("MASTER MIXER", 18, Color.WHITE);
        mixTitle.setTypeface(null, Typeface.BOLD); root.addView(mixTitle);
        root.addView(label("CROSSFADER     A  ◀──────●──────▶  B", 12, cyan));
        crossfader = slider(100, 50); root.addView(crossfader);
        crossfader.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s,int p,boolean u){ updateVolumes(); }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });
        root.addView(label("Move the crossfader to blend Deck A and Deck B", 11, Color.LTGRAY));
        TextView foot = label("PRANIT DJ  •  MIX YOUR SOUND", 11, Color.GRAY);
        root.addView(foot);
        setContentView(scroll);
    }
    private void buildDeck(Deck d, View container) {
        LinearLayout box = (LinearLayout)container;
        String deckName = d.index == 0 ? "DECK A" : "DECK B";
        TextView name = label(deckName, 18, cyan); name.setTypeface(null, Typeface.BOLD);
        box.addView(name);
        TextView platter = label("◉", 66, Color.WHITE);
        platter.setBackground(rounded(Color.rgb(7,10,15), Color.rgb(60,75,95)));
        box.addView(platter, new LinearLayout.LayoutParams(-1, 120));
        d.track = label("No track loaded", 11, Color.WHITE);
        box.addView(d.track);
        Button load = button("＋ LOAD SONG");
        box.addView(load);
        load.setOnClickListener(v -> {
            pickerDeck = d.index;
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("audio/*");
            startActivityForResult(i, 77);
        });
        d.play = button("▶ PLAY"); box.addView(d.play);
        d.play.setOnClickListener(v -> d.toggle());
        d.time = label("SEEK", 10, Color.LTGRAY); box.addView(d.time);
        d.seek = slider(1000,0); box.addView(d.seek);
        d.seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s,int p,boolean u){
                if (u && d.player != null) d.player.seekTo(p);
            }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });
        d.volume = slider(100,80); box.addView(label("CHANNEL LEVEL",10,Color.LTGRAY)); box.addView(d.volume);
        d.volume.setOnSeekBarChangeListener(simpleListener());
        addEq(box, d, "BASS", 50, 0);
        addEq(box, d, "MID", 50, 1);
        addEq(box, d, "TREBLE", 50, 2);
    }
    private void addEq(LinearLayout box, Deck d, String name, int value, int which) {
        box.addView(label(name,10,Color.LTGRAY));
        SeekBar s = slider(100,value); box.addView(s);
        if (which == 0) d.low = s; else if (which == 1) d.mid = s; else d.high = s;
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b,int p,boolean u){ d.applyEq(); }
            public void onStartTrackingTouch(SeekBar b){}
            public void onStopTrackingTouch(SeekBar b){}
        });
    }
    private SeekBar.OnSeekBarChangeListener simpleListener() {
        return new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s,int p,boolean u){ updateVolumes(); }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        };
    }
    private void updateVolumes() {
        if (left == null || right == null || crossfader == null) return;
        float x = crossfader.getProgress() / 100f;
        if (left.player != null) left.player.setVolume(left.volume.getProgress()/100f * (1f-x), left.volume.getProgress()/100f * (1f-x));
        if (right.player != null) right.player.setVolume(right.volume.getProgress()/100f * x, right.volume.getProgress()/100f * x);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == 77 && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch(Exception ignored) {}
                (pickerDeck == 0 ? left : right).load(uri);
            }
        }
    }
    @Override protected void onDestroy() {
        if (left != null) left.release();
        if (right != null) right.release();
        super.onDestroy();
    }
}
